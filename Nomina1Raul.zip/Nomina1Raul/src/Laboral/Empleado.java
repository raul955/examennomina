package Laboral;

public class Empleado extends Persona{
	
	private int categoria;
	public int anyos;
	
	public Empleado(int categoria, int anyos) throws Exception{
		
		this.categoria = categoria;
		this.anyos = anyos;
		
		if(categoria<0 || categoria>10) {
			throw new Exception("La categoría debe estar entre 0 y 10");
			
		}
		
		if(anyos<0) {
			System.out.println("ERR0R, años negativos.");
		}
		
	}

	public Empleado(String nombre, String dni, char sexo) {
		super(nombre, dni, sexo);
		this.categoria=1;
		this.anyos=0;
	}
	
	

	public Empleado(String nombre, String dni, char sexo, int categoria, int anyos) {
		super(nombre, dni, sexo);
		this.categoria = categoria;
		this.anyos = anyos;
	}

	public int getCategoria() {
		return categoria;
	}

	public void setCategoria(int categoria) {
		this.categoria = categoria;
	}

	public int getAnyos() {
		return anyos;
	}

	public void setAnyos(int anyos) {
		this.anyos = anyos;
	}

	@Override
	public String toString() {
		return "Empleado categoria=" + categoria + ", anyos=" + anyos + ", nombre=" + nombre + ", dni=" + dni
				+ ", sexo=" + sexo + " ";
	}
	
	public void incranyos(Empleado f) {
		f.setAnyos(anyos+1);
	}
	

}


