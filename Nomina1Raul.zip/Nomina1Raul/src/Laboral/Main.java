package Laboral;

public class Main {

	public static void main(String args[]) {

		Empleado m = new Empleado("James Cosling", "32000032G", 'M', 4, 7);
		Empleado f = new Empleado("Ada Lovelace", "32000031R", 'F');

		escribeTodo(m, f);

		f.incranyos(f);
		m.setCategoria(9);

		escribeTodo(m, f);

	}

	private static void escribeTodo(Empleado m, Empleado f) {

		final int SUELDO_BASE[] = { 50000, 70000, 90000, 110000, 130000, 150000, 170000, 190000, 210000, 230000 };

		int im = m.getCategoria();
		int catm = m.getAnyos();

		int iff = f.getCategoria();
		int catf = f.getAnyos();

		int salariom = SUELDO_BASE[im] + (5000 * catm);
		int salariof = SUELDO_BASE[iff] + (5000 * catf);

		System.out.print(m.toString());
		System.out.println(", salario=" + salariom);
		System.out.println(" ");
		System.out.print(f.toString());
		System.out.println(", salario=" + salariof);

	}

	@SuppressWarnings("unused")
	private static void calcularnomina(Empleado m, Empleado f) {

		final int SUELDO_BASE[] = { 50000, 70000, 90000, 110000, 130000, 150000, 170000, 190000, 210000, 230000 };

		int im = m.getCategoria();
		int catm = m.getAnyos();

		int iff = f.getCategoria();
		int catf = f.getAnyos();

		int salariom = SUELDO_BASE[im] + (5000 * catm);
		int salariof = SUELDO_BASE[iff] + (5000 * catf);

	}

}
