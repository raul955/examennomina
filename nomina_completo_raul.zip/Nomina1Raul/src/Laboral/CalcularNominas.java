package Laboral;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;





public class CalcularNominas implements Serializable{

	public static void main(String args[]) {
		
		Scanner s = new Scanner(System.in);
		Scanner sc = new Scanner(System.in);
		int scan;
		
		try {
				
			Leer_Fichero accediendo = new Leer_Fichero();
					
			System.out.println("Primera lectura del fichero");
			accediendo.lee();
					
			Empleado james = new Empleado("James Cosling", "48124096T", 'M', 4,7);
			Empleado ada = new Empleado("Ada Lovelace","48811600B",'F');
			System.out.println("\n");
			System.out.println("-------------------------------------\nPrimera escritura en consola");
			escribe(james, ada);
			
			
			ada.incrAnyos();
			
			
			james.setCategoria(9);
			
			System.out.println("------------------------------------\nEscritura con modificacion de datos");
			escribe(james,ada);
			System.out.println("-------------------------------------");
			System.out.println("Leyendo del fichero datos modificados");
			accediendo.lee();
		
			//escritura de los datos en fichero
			escribebinario(james, ada);
			
			//metodo para dar de alta empleados, no funciona, no entiendo por qu�.
			Empleado raul = new Empleado("Ra�l Naranjo", "12345678E", 'M', 8,8);
			Empleado.altaEmpleado(raul);
			
			//backups
			Backup b = new Backup();
			Backup.backups();
			
			
		}catch (DatosIncorrectosException escribe) {
			
			System.out.println(escribe.toString());
			
		}

		
		/**
		 *  CREATE TABLE empleados(
			nombre varchar2(100),
			dni varchar2(100),
			sexo varchar2(100),
			categoria varchar2(100),
			anyos NUMBER(5)
			);

			create table nominas(
			sueldo number(20)
			);
			
			alter table nominas add nombre varchar2(100);
			alter table nominas add dni varchar2(100);
		 */
		
		try{
			
			Class.forName ("oracle.jdbc.driver.OracleDriver");
			
			// 1. Crear conexion
			
			String url = "jdbc:oracle:thin:@192.168.56.101:1521:xe";
			Connection miConexion = DriverManager.getConnection(url, "empleado", "empleado");
			
			// 2. Crear objeto statement
			
			Statement miStatement = miConexion.createStatement();
			
			String instruccionSQL="insert into empleados(nombre,dni,sexo,categoria,anyos)values('James Cosling','48124096T','M','4',7)";
			
			miStatement.executeUpdate(instruccionSQL);
			
			String instruccionSQL2="insert into empleados(nombre,dni,sexo,categoria,anyos)values('Ada Lovelace','48811600B','F','','')";
			
			miStatement.executeUpdate(instruccionSQL2);
			
			String instruccionSQL3="DELETE FROM empleados where nombre = 'James Cosling'";
			
			miStatement.executeUpdate(instruccionSQL3);
			
			String instruccionSQL4="DELETE FROM empleados where nombre = 'Ada Lovelace'";
			
			miStatement.executeUpdate(instruccionSQL4);
			
			String instruccionSQL5="insert into empleados(nombre,dni,sexo,categoria,anyos)values('James Cosling','48124096T','M','9',7)";
			
			miStatement.executeUpdate(instruccionSQL5);
			
			String instruccionSQL6="insert into empleados(nombre,dni,sexo,categoria,anyos)values('Ada Lovelace','48811600B','F','1','1')";
			
			miStatement.executeUpdate(instruccionSQL6);
			
			String instruccionSQL7="insert into nominas(sueldo,nombre,dni)values(245000,'James Cosling','48124096T')";
			
			miStatement.executeUpdate(instruccionSQL7);
			
			String instruccionSQL8="insert into nominas(sueldo,nombre,dni)values(55000,'Ada Lovelace','48811600B')";
			
			miStatement.executeUpdate(instruccionSQL8);
			
			System.out.println("");
			System.out.println("Los datos se han modificado correctamente en la base de datos");
			
			
			
		}catch(Exception e){
			
			System.out.println("No ha sido posible la conexi�n 001.");
			
			e.printStackTrace();
			
		}
		
		System.out.println(" ");
		System.out.println("-------------------------------------------");
		
		System.out.println("Seleccione una de las siguientes opciones: ");
		do{
		System.out.println("1.- Mostrar informaci�n de los empleados.");
		System.out.println("2.- Mostrar salario de empleado");
		System.out.println("3-. No implementado");
		System.out.println("4-. No implementado");
		System.out.println("5-. No implementado");
		System.out.println("6-. Realizar copia de seguridad en ficheros");
		System.out.println("Cualquier otro para salir");
		scan=s.nextInt();
		
		if(scan==1){
			try {

				Class.forName("oracle.jdbc.driver.OracleDriver");

				// 1. Crear conexion

				String url = "jdbc:oracle:thin:@192.168.56.101:1521:xe";
				Connection miConexion = DriverManager.getConnection(url, "empleado", "empleado");

				// 2. Crear objeto statement

				Statement miStatement = miConexion.createStatement();

				// 3. Ejecutar SQL

				ResultSet miResultSet = miStatement.executeQuery("SELECT * FROM empleados");

				// 4. Recorrer el resultSet

				while (miResultSet.next()) {

					System.out.println(miResultSet.getString("nombre") + " " + miResultSet.getString("dni") + " "
							+ miResultSet.getString("categoria") + " " + miResultSet.getString("anyos"));

				}

			} catch (Exception e) {

				System.out.println("No ha sido posible la conexi�n.");

				e.printStackTrace();

			}
		}else if(scan==2){
			try {
				String name;
				System.out.println("Introduce el dni del empleado");
				name = sc.nextLine();
				Class.forName("oracle.jdbc.driver.OracleDriver");

				// 1. Crear conexion

				String url = "jdbc:oracle:thin:@192.168.56.101:1521:xe";
				Connection miConexion = DriverManager.getConnection(url, "empleado", "empleado");

				// 2. Crear objeto statement

				Statement miStatement = miConexion.createStatement();

				// 3. Ejecutar SQL

				ResultSet miResultSet2 = miStatement.executeQuery("SELECT sueldo FROM nominas where dni='"+name+"'");

				// 4. Recorrer el resultSet

				while (miResultSet2.next()) {

					System.out.println(miResultSet2.getInt("sueldo"));

				}

			} catch (Exception e) {

				System.out.println("No ha sido posible la conexi�n.");

				e.printStackTrace();

			}
		}else if(scan==3){
			System.out.println("Funci�n no implementada");
		}else if(scan==4){
			System.out.println("Funci�n no implementada");
		}else if(scan==5){
			System.out.println("Funci�n no implementada");
		}else if(scan==6){
			
			Backup.backups();
			System.out.println("Copia de seguridad realizada");
		}
		
		}while(scan == 1||scan==2||scan==3||scan==4||scan==5||scan==6);
		
		
	}
	

	/**
	 * escribo el dni y el sueldo en un fichero sueldos.txt, ha sido necesario 
	 * añadir un metodo toString en la clase empleado y el get de dni en la clase
	 * persona.
	 * @param emp1
	 * @param emp2
	 */
	public static void escribebinario(Empleado emp1, Empleado emp2) {
		
		String fileSueldos = (emp1.toString()+",sueldo:"+ Nomina.sueldo(emp1));
		String fileSueldos2 = (emp2.toString()+",sueldo:"+ Nomina.sueldo(emp2));
		
		try {
			
			FileWriter escritura =  new FileWriter("sueldos.txt");
			//FileOutputStream escritura = new FileOutputStream("sueldos.dat");
			
			escritura.write(fileSueldos);

			escritura.write(fileSueldos2);
			
			escritura.close();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	
	
	/**
	 * Implemento la escritura en el fichero empleados.txt en el método escribe
	 * 
	 * @param emp1
	 * @param emp2
	 */
	private static void escribe(Empleado emp1, Empleado emp2) {
		
		System.out.println(emp1.imprime()+",sueldo:"+ Nomina.sueldo(emp1));
		System.out.println(emp2.imprime()+",sueldo:"+ Nomina.sueldo(emp2));

		String datos = (emp1.imprime()+",sueldo:"+ Nomina.sueldo(emp1));
		String datos2 = (emp2.imprime()+",sueldo:"+ Nomina.sueldo(emp2));
		
		try {
			FileWriter escritura =  new FileWriter("empleados.txt");
			
			escritura.write(datos);
			escritura.append("\r\n");
			escritura.write(datos2);
			
			escritura.close();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	
	
	

}
